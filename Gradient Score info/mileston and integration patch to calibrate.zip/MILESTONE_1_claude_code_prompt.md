# Milestone 1 — Claude Code Prompt
## Deploy Calibration to the Live Prototype

> Paste the prompt below directly into Claude Code, opened in your
> prototype repo (the Heroku Gradient Score Engine repo, NOT the v2.0 mobile repo).
>
> Before pasting: copy these four files into the repo root:
>   - signal_calibration_integration.py
>   - calibration_parameter_corrections.py
>   - ai_topic_intelligence.py
>   - calibration_engine.py   (already exists — confirm it's there)
>   - research_history.py      (already exists — confirm it's there)

---

## THE PROMPT (copy everything in this block)

```
I need you to integrate four calibration modules into the existing
Gradient Score engine and deploy to Heroku. Work in this exact order
and confirm each step compiles before moving on. Do NOT change the
core scoring math — only add the calibration layer around it.

CONTEXT:
- This is the Now TrendIn Gradient Score prototype (Django/FastAPI + Postgres on Heroku)
- The main scoring file is gravitational_anomaly_detector.py
- Four calibration modules are now in the repo root:
    signal_calibration_integration.py  (maturity calibration + known topics seed)
    calibration_parameter_corrections.py (0.40 multiplier, noise filter, signal modifier)
    ai_topic_intelligence.py            (tier-aware AI topic scoring)
    calibration_engine.py               (core engine — already present)

PROBLEM I'M SOLVING:
- "ai agent" currently scores 22/11 — should be calibrated as ESTABLISHED
- "agentic coding", "agent memory", "12-factor agents" should score 90+
- Bigram noise like "actually costs", "advice almost" floods the results
- Everything scores the same because of single-collection-run sparsity

STEP 1 — Confirm imports work
Open a Python shell on the repo and confirm all four modules import
without error. Report any missing dependencies.

STEP 2 — Initialize and seed the calibration database
Add to the startup sequence in gravitational_anomaly_detector.py
(near the top, after DB_PATH is defined):

    from signal_calibration_integration import (
        apply_calibration, seed_known_topics, init_calibration_db
    )
    from calibration_parameter_corrections import (
        apply_signal_count_modifier, filter_topics_batch
    )
    from ai_topic_intelligence import apply_ai_intelligence

    init_calibration_db(DB_PATH)
    seed_known_topics(DB_PATH)

STEP 3 — Add the signal count modifier inside score_topic()
Find where raw_gradient (or gradient_strength) is computed inside
score_topic(). Immediately AFTER that line, add:

    raw_gradient = apply_signal_count_modifier(
        raw_gradient,
        signal_count   = total_signals,
        platform_count = platform_count,
    )

(Use the actual variable names in the file — total_signals may be
called total_mentions or signal_count. Match what exists.)

STEP 4 — Add calibration + AI intelligence at the end of score_topic()
Find the final "return result" (or "return score_dict") in score_topic().
Immediately BEFORE the return, add these two lines in this exact order:

    result = apply_calibration(result, db_path=DB_PATH)
    result = apply_ai_intelligence(result)
    return result

Order matters: apply_calibration runs first (general maturity calibration),
then apply_ai_intelligence overrides scores for known AI topics only.
Non-AI topics pass through apply_ai_intelligence unchanged.

STEP 5 — Add the noise filter at the list/endpoint level
Find the endpoint that returns all scored topics (likely /scores or
get_all_scores or similar). After the list of scored topics is built,
before returning, add:

    scored_topics = filter_topics_batch(scored_topics, min_signal_count=3)

This removes bigram noise like "actually costs" while keeping real
AI topics.

STEP 6 — Test locally before deploying
Run the scorer locally on a few topics and confirm:
  - "ai agent" returns maturity_class ESTABLISHED, calibrated gradient ~21
  - "agentic coding" returns ai_tier "tier_1" with high scores
  - "actually costs" is filtered out of the results list
Report the actual output for these three topics.

STEP 7 — Deploy to Heroku
Once local tests pass:
    git add .
    git commit -m "feat: integrate calibration + AI topic intelligence layer"
    git push heroku main

Then run the seed on the live database:
    heroku run "python signal_calibration_integration.py --seed"

STEP 8 — Verify on the live prototype
Run:
    heroku run "python signal_calibration_integration.py --analyse ai_agent"
Confirm it returns maturity_class: ESTABLISHED, multiplier: 0.40.

Then run:
    heroku run "python signal_calibration_integration.py --report"
Confirm the known topics are seeded and showing correct classifications.

STEP 9 — Set up continuous collection (Heroku Scheduler)
Add the scheduler addon and confirm these jobs are configured:
    heroku addons:create scheduler:standard
    heroku addons:open scheduler
Add two jobs in the dashboard:
    Job 1: python gravitational_anomaly_detector.py --mode=collect   (every 30 min)
    Job 2: python gravitational_anomaly_detector.py --mode=score     (every 30 min)
Also add the daily velocity recompute:
    Job 3: python -c "from signal_calibration_integration import recompute_velocities; recompute_velocities()"   (daily 6am)

After each step, tell me exactly what you changed and what the output was.
Do not move to the next step until the current one is confirmed working.
```

---

## WHAT SUCCESS LOOKS LIKE

After this prompt completes and 24 hours of collection has run, open the
prototype and you should see:

```
TOP OF THE LIST (Tier 1 — should be near the top):
  agentic coding      DET ~95+   CONF ~93+   🟢 VIRAL
  agent memory        DET ~92+   CONF ~88+   🟢 VIRAL
  12-factor agents    DET ~90+   CONF ~85+   🟢 VIRAL

MIDDLE (Tier 2):
  mcp                 DET ~82    CONF ~78    🔵 STRONG
  claude code         DET ~80    CONF ~76    🔵 STRONG

LOWER (Tier 3 — correctly calibrated as established):
  ai agent            DET ~26    CONF ~17    ⚪ ESTABLISHED
  agentic ai          DET ~27    CONF ~18    ⚪ ESTABLISHED
  llm                 DET ~29    CONF ~21    ⚪ ESTABLISHED

FILTERED OUT (no longer appear):
  "actually costs", "advice almost", "agents loose payment", etc.
```

That screenshot is your proof the instrument works. Save it — it is the
single most valuable asset for any investor or anchor-client conversation.

---

## IF SOMETHING GOES WRONG

**Import errors:** The modules depend on each other. Confirm all five files
(the four above plus research_history.py) are in the repo root.

**"topic_maturity table not found":** init_calibration_db() did not run.
Run `heroku run "python signal_calibration_integration.py --seed"` manually.

**Scores still showing raw values:** The apply_calibration() / apply_ai_intelligence()
lines were not added before the return statement, or were added after it.
Confirm they run BEFORE `return result`.

**Everything still 22/11:** This is expected until 24 hours of continuous
collection has run. Inertia and persistence need multiple windows. The
TIER classification (from ai_topic_intelligence) is accurate immediately,
but the full score climb requires data accumulation.
